const express = require("express");
const app = express();
const PORT = 3000;

// parse query string value to a number, NaN if missing/invalid
const toNumber = (v) => (v === undefined || v.trim() === "" ? NaN : Number(v));

// WS1: Hello Express
app.get("/", (req, res) => {
  res.send("Hello Express");
});

// WS2: Multiple routes
app.get("/about", (req, res) => {
  res.send("About");
});

app.get("/contact", (req, res) => {
  res.send("Contact");
});

// WS3: JSON response
app.get("/student", (req, res) => {
  res.json({
    name: "Alice",
    id: "6512345678",
    major: "Computer Science",
  });
});

// WS4: Path parameters
app.get("/product/:id", (req, res) => {
  res.send(`Product ID : ${req.params.id}`);
});

// WS5: Query parameters
app.get("/square", (req, res) => {
  const n = toNumber(req.query.number);
  if (Number.isNaN(n)) return res.status(400).send("number must be numeric");
  res.send(`Square = ${n * n}`);
});

// WS6: Grade calculator
app.get("/grade", (req, res) => {
  const score = toNumber(req.query.score);
  if (Number.isNaN(score) || score < 0 || score > 100) {
    return res.status(400).send("score must be a number between 0 and 100");
  }

  let grade = "F";
  if (score >= 80) grade = "A";
  else if (score >= 70) grade = "B";
  else if (score >= 60) grade = "C";
  else if (score >= 50) grade = "D";

  res.send(`Grade : ${grade}`);
});

// WS7: Mini REST API
const books = [
  { id: 1, title: "HTML" },
  { id: 2, title: "JavaScript" },
];

app.get("/books", (req, res) => {
  res.json(books);
});

// 404 fallback
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
